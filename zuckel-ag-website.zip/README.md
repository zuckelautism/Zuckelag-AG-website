# Zuckel AG — Firmenwebsite

Mehrseitige Firmenwebsite für die Zuckel Aktiengesellschaft (Stellari Continuum RP).
Statisches Frontend (HTML/CSS/JS, kein Build-Tool nötig) + Firebase als kostenloses
Backend (Firestore-Datenbank + Authentication für den Admin-Login).

Jeder Besucher sieht dieselben Live-Daten. Nur wer sich mit einem echten
Firebase-Konto einloggt, kann Inhalte bearbeiten.

## Seiten

| Datei | Inhalt |
|---|---|
| `index.html` | Startseite, Führung, Live-Kennzahlen |
| `standorte.html` | Standorte/Außenposten (admin-bearbeitbar) |
| `mitarbeiter.html` | Mitarbeiterregister mit IGN (admin-bearbeitbar) |
| `unternehmenswert.html` | Aktueller Unternehmenswert + Verlauf (admin-bearbeitbar) |
| `anteile.html` | Investor Relations / Anteilseigner-Diagramm (admin-bearbeitbar) |
| `karriere.html` | Offene Positionen (admin-bearbeitbar) |
| `impressum.html` | Kontakt/Impressum (statisch) |

## Setup (einmalig, ca. 10 Minuten, komplett kostenlos)

Der kostenlose Firebase **Spark-Plan** verlangt keine Kreditkarte und deckt ein
Projekt dieser Größe locker ab (u. a. ca. 50.000 Lesevorgänge und 20.000
Schreibvorgänge pro Tag bei Firestore, 50.000 Logins/Monat bei Authentication —
aktuelle Werte siehe [firebase.google.com/pricing](https://firebase.google.com/pricing)).

### 1. Firebase-Projekt erstellen
1. Gehe zu [console.firebase.google.com](https://console.firebase.google.com) und logge dich mit einem Google-Konto ein.
2. „Projekt hinzufügen" → Namen vergeben (z. B. `zuckel-ag`) → Google Analytics kannst du deaktivieren, wird hier nicht benötigt.

### 2. Firestore aktivieren
1. Im Projekt: **Build → Firestore Database → Datenbank erstellen**.
2. Modus: **Im Produktionsmodus starten** (die Regeln setzen wir gleich selbst, siehe unten).
3. Region wählen (egal welche, am besten eine in deiner Nähe) → Erstellen.

### 3. Authentication aktivieren + Admin-Konto anlegen
1. **Build → Authentication → Erste Schritte**.
2. Anbieter **E-Mail/Passwort** aktivieren (Toggle umlegen, Speichern).
3. Tab **Nutzer** → **Nutzer hinzufügen** → E-Mail + Passwort des Admins eintragen.
   Es gibt **keine öffentliche Registrierung** auf der Seite selbst — neue
   Admin-Zugänge legst du immer hier in der Konsole an, manuell.

### 4. Web-App registrieren
1. Zahnrad oben links → **Projekteinstellungen → Allgemein**.
2. Ganz unten bei „Deine Apps" → Web-Symbol `</>` klicken.
3. Spitznamen vergeben (z. B. „Website") → **Nicht** „Firebase Hosting einrichten" anhaken, das brauchen wir nicht (wir hosten über GitHub Pages) → Registrieren.
4. Das angezeigte `firebaseConfig`-Objekt kopieren.

### 5. Config eintragen
Öffne `assets/firebase-config.js` und ersetze die leeren Werte mit deinem
kopierten Config-Objekt:

```js
export const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};
```

Diese Werte sind **nicht geheim** — sie sagen nur, mit welchem Firebase-Projekt
geredet wird. Der eigentliche Schutz passiert über die Firestore-Regeln (Schritt 6)
und den Login (Schritt 3), nicht durch Verstecken dieser Datei.

### 6. Firestore-Sicherheitsregeln einfügen
**Firestore Database → Regeln** → vorhandenen Text ersetzen durch:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

→ **Veröffentlichen**. Das heißt: jeder darf lesen, aber nur eingeloggte
Admins (die du in Schritt 3 angelegt hast) dürfen schreiben.

### 7. GitHub-Pages-Domain freigeben
1. **Authentication → Settings → Autorisierte Domains** → **Domain hinzufügen**.
2. Trag deine GitHub-Pages-Domain ein, z. B. `dein-name.github.io`.

### 8. Auf GitHub Pages veröffentlichen
1. Den kompletten Inhalt dieses Ordners in dein Repository pushen (Ordnerstruktur
   muss erhalten bleiben — `assets/` muss neben den `.html`-Dateien liegen).
2. Repo → **Settings → Pages** → Branch auswählen (z. B. `main`, Ordner `/`) → Speichern.
3. Nach 1–2 Minuten ist die Seite unter `https://dein-name.github.io/dein-repo/` erreichbar.

### 9. Erste Inhalte eintragen
Auf der Seite oben rechts/unten **„Admin-Zugang"** klicken, mit dem Konto aus
Schritt 3 einloggen. Login gilt seitenübergreifend, bis du dich abmeldest.
Dann auf jeder Seite **„Bearbeiten"** nutzen, um die ersten Standorte,
Mitarbeiter, den Unternehmenswert und die Anteilseigner einzutragen — die
Datenbank ist anfangs leer, dafür gibt's überall einen Hinweistext.

## Lokal testen, bevor du pushst

Die Seiten nutzen ES-Module (`<script type="module">`). Browser blockieren
deren Import, wenn man eine HTML-Datei per Doppelklick (`file://`) öffnet.
Zum lokalen Testen brauchst du einen simplen lokalen Server, z. B.:

```
python3 -m http.server 8000
```

…im Projektordner ausführen, dann `http://localhost:8000` im Browser öffnen.
Über GitHub Pages läuft alles automatisch über `https://`, dort ist das kein Problem.

## Weitere Admin-Zugänge hinzufügen

Firebase Console → Authentication → Nutzer → Nutzer hinzufügen. Jeder, der
dort einen Account bekommt, kann sich auf der Seite einloggen und überall
bearbeiten (alle Admins haben dieselben Rechte — es gibt keine Rollen-Abstufung).

## Datenmodell (für eigene Anpassungen)

| Collection | Felder |
|---|---|
| `locations` | `name, status (active/building/planned), description, coords, createdAt` |
| `employees` | `ign, role, location, joinedDate, status (active/inactive), createdAt` |
| `careers` | `title, description, createdAt` |
| `shares` | `name, role, percent, createdAt` |
| `valuation/current` | (einzelnes Dokument) `value, unit, updatedAt` |
| `valuationHistory` | `value, note, createdAt` |

## Dateistruktur

```
index.html
standorte.html
mitarbeiter.html
unternehmenswert.html
anteile.html
karriere.html
impressum.html
assets/
  styles.css          ← gemeinsames Design, einmal ändern wirkt überall
  firebase-config.js   ← hier deine Firebase-Projektdaten eintragen
  common.js            ← Firebase-Init, Login-Logik, Toast, Hilfsfunktionen
  img/logo.png
  pages/
    home.js, standorte.js, mitarbeiter.js, unternehmenswert.js, anteile.js, karriere.js, impressum.js
```

## Bekannte Grenzen

- Es gibt keine Rollen/Rechte-Abstufung — jeder Firebase-Login ist Vollzugriff.
- Kein Bild-Upload eingebaut (Firebase Cloud Storage ist seit einer Änderung 2026
  nicht mehr im kostenlosen Spark-Plan enthalten). Bilder bleiben aktuell auf das
  Logo in `assets/img/` beschränkt.
- Bei sehr vielen gleichzeitigen Bearbeitungen am selben Eintrag gilt
  "wer zuletzt speichert, gewinnt" (kein Konflikt-Handling).
